import xlwt
from xlwt.Worksheet import Worksheet

workbook = xlwt.Workbook(encoding='utf-8')  #创建workbook对象
Worksheet = workbook.add_sheet('sheet1')    #创建工作表
Worksheet.write(0,0,'hello')                #写入数据，第一个参数‘行’，第二个参数‘列’，第三个参数：内容
workbook.save('test.xls')                   #保存数据

#书写99乘法表，写入到xls  

workbook = xlwt.Workbook(encoding='utf-8')  #创建workbook对象
Worksheet = workbook.add_sheet('sheet1')    #创建工作表
for i in range(0,9):
    for j in range(0,9):
        Worksheet.write(i,j,"%d * %d = %d"%(i+1,j+1,(i+1)*(j+1)))
workbook.save('99乘法表.xls')                #保存数据