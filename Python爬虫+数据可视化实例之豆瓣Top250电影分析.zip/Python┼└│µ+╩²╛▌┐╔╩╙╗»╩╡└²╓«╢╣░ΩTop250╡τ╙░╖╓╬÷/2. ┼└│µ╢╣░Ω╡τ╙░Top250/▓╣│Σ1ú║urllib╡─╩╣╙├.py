import urllib.request
# 读取网页内容
response = urllib.request.urlopen("http://www.baidu.com")
print(response.read().decode('utf-8'))
