# 模块（库） 就是别人写好的源代码，

def add(a,b):
    return a+b

def minus(a,b):
    return a-b

