# 出现“ModuleNotFoundError: No module named 'TestModule' ”错误提示，添加：
import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

# 调用TestModule库
from TestModule import test1

print(test1.add(2,3))

print(test1.minus(2,3))

