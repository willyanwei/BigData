# 建议使用jupyter notebook
# 环境
# 192.168.0.116:8888

# python读取xls中一列，转化为数组
'''
import pandas as pd
def excel_one_line_to_list():
    df = pd.read_excel("D:\F\Python\Python爬虫编程基础5天速成\豆瓣电影Top250.xls", usecols=[4], names=None)  # 读取第五列列,不要列名
    df_li = df.values.tolist()
    result = []
    for s_li in df_li:
        result.append(s_li[0])
    print(result)
if __name__ == '__main__':
    excel_one_line_to_list()
'''

# 输出两列： 影片中文名，评分
import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Bar
def excel_videoname_to_list():
    df = pd.read_excel("D:\F\Python\Python爬虫编程基础5天速成\豆瓣电影Top250.xls", usecols=[2], names=None)  # 读取第五列列,不要列名
    df_li = df.values.tolist()
    videoname = []
    for s_li in df_li:
        videoname.append(s_li[0])
    print(videoname)
if __name__ == '__main__':
    excel_videoname_to_list()

def excel_score_to_list():
    df = pd.read_excel("D:\F\Python\Python爬虫编程基础5天速成\豆瓣电影Top250.xls", usecols=[4], names=None)  # 读取第五列列,不要列名
    df_li = df.values.tolist()
    score = []
    for s_li in df_li:
        score.append(s_li[0])
    print(score)
if __name__ == '__main__':
    excel_score_to_list()


c = (
    Bar()
    .add_xaxis(excel_videoname_to_list)
    .add_yaxis("商家A", excel_score_to_list,color='')
    .set_global_opts(
        title_opts=opts.TitleOpts(title="Bar-DataZoom（slider+inside）"),
        datazoom_opts=[opts.DataZoomOpts(), opts.DataZoomOpts(type_="inside")],
    )
    .render("bar_datazoom_douban.html")
)