
# python读取xls中的列，转化为数组
# 输出两列： 影片中文名，评分
import pandas as pd
from pyecharts import options as opts
from pyecharts.charts import Bar

# 输出电影名字videoname
df1 = pd.read_excel("D:\F\Python\Python爬虫编程基础5天速成\豆瓣电影Top250.xls", usecols=[2], names=None)  # 读取第五列列,不要列名
df1_li = df1.values.tolist()
videoname = []
for s_li in df1_li:
    videoname.append(s_li[0])
print(videoname)

# 输出打分score
df2 = pd.read_excel("D:\F\Python\Python爬虫编程基础5天速成\豆瓣电影Top250.xls", usecols=[4], names=None)  # 读取第五列列,不要列名
df2_li = df2.values.tolist()
score = []
for s_li in df2_li:
    score.append(s_li[0])
print(score)

# 可视化
c = (
    Bar()
    .add_xaxis(videoname)
    .add_yaxis("豆瓣Top250电影评分", score)
    .set_global_opts(
        title_opts=opts.TitleOpts(title="Bar-DataZoom（slider+inside）"),
        datazoom_opts=[opts.DataZoomOpts(), opts.DataZoomOpts(type_="inside")],
    )
    .render("bar_datazoom_douban.html")
)

